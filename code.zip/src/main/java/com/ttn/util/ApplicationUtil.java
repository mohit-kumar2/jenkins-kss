package com.ttn.util;

import org.springframework.stereotype.Component;

/**
 * Created by harkesh on 18/8/17.
 */
public class  ApplicationUtil {

  public  int sum(int a, int b){
    return a+b;
  }
}
